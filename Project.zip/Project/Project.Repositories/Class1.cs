﻿namespace Project.Repositories
{
    public class Class1
    {

    }
}